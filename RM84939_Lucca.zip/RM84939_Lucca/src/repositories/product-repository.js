const mongoose = require('mongoose');
const Product = mongoose.model('Product');


exports.getProduct = async () => {
    const result = await Product.find({}, 'title price description _id active');

    return result;
}

exports.create = async (data) => {
    const produto = Product(data);
    await produto.save();
}

exports.put = async (data) => {
    await Product.findByIdAndUpdate(id, {
        $set:{
            title: data.title,
            description: data.description,
            price: data.price,
            active: data.active
        }
    });
}

exports.getById = async (id) => {
    const resultado = await Product.findOne({ _id : id}, "_id title description preice active")
    return resultado;
}

exports.delete = async (id) => {
    await Product.findByIdAndUpdate(id);
}